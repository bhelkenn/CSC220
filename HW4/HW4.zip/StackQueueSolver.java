// Name: Brady Helkenn
// Andrewid: 915905476
// Section: CSC 220.03

public class StackQueueSolver {
	
	public static int lastCustomer(int numPersons, int numToBack) {
	    throw new UnsupportedOperationException("remove this line");
	}

	// Runtime O(n)
	public static <E> boolean areEqual(MyStack<E> stack1, MyStack<E> stack2) {
	    throw new UnsupportedOperationException("remove this line");
	}
	
	
	// Runtime O(n)
	public static <E> MyStack<E> duplicateStack(MyStack<E> original) {
	    throw new UnsupportedOperationException("remove this line");
	}
	
	public static void main(String[] args) {
		// Write tester code
	}


}